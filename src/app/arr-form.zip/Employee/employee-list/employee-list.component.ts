import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from 'src/app/services/employee.service';
import { EncryptionService } from 'src/app/services/encryption.service';
import Chart from 'chart.js/auto';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employeeList: any = [];
  constructor(private empService: EmployeeService,
    private router: Router,
    private encryptionService:EncryptionService
  ) { }

  ngOnInit(): void {
    this.getEmployeeList();
    this.createChart();
  }
  
  public chart: any;
  createChart(){

    this.chart = new Chart("MyChart", {
      type: 'pie', //this denotes tha type of chart

      data: {// values on X-Axis
        labels: ['Red', 'Pink','Green','Yellow','Orange','Blue', ],
	       datasets: [{
    label: 'My First Dataset',
    data: [300, 240, 100, 432, 253, 34],
    backgroundColor: [
      'red',
      'pink',
      'green',
			'yellow',
      'orange',
      'blue',			
    ],
    hoverOffset: 4
  }],
      },
      options: {
        aspectRatio:2.5
      }

    });
  }

    // Chart.js data and options
  public pieChartOptions: any = {
    responsive: true
  };

  public pieChartLabels: string[] = ['Red', 'Green', 'Blue'];
  public pieChartData: number[] = [300, 500, 200];
  public pieChartType: string = 'pie';

  getEmployeeList() {
    this.empService.getEmployeeList().subscribe(item => {
      this.employeeList = item;
    });
  }

  onEdit(id: any) {
    let encData  = this.encryptionService.encrypt(id);
    console.log("encData = " +encData);
    let decData = this.encryptionService.decrypt(encData);
    console.log("decData = " + decData)

    let encryptId = btoa(id);
    this.router.navigate([`/editemployee/${encryptId}`])
  }

}
