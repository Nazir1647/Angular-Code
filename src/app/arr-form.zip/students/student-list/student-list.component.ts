import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent {
  @Input() studentList = [];
  @Output() studentDetails: any = new EventEmitter();

  onEdit(data:any,type: string){
    this.studentDetails.emit(data,12);
  }

  onDelete(data:any){

  }

}
