import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { error } from 'jquery';
import { StudentService } from 'src/app/services/student.service';


@Component({
  selector: 'app-addstudent',
  templateUrl: './addstudent.component.html',
  styleUrls: ['./addstudent.component.css']
})
export class AddstudentComponent implements OnInit {

  genderArr = [
    { id: 1, name: 'Male' },
    { id: 2, name: 'Female' }
  ];

  hobbiesArr = [
    { value: 1, name: 'Cricket', isSelected: false },
    { value: 2, name: 'Football', isSelected: false },
    { value: 3, name: 'Tennis', isSelected: false },
    { value: 4, name: 'Hockey', isSelected: false }
  ];

  countryList: any = [];
  stateList: any = [];
  studentForm: FormGroup;
  employeeDetails: any;
  buttonName = "Save";
  submitted: boolean = false;
  studentList: any = [];

  constructor(private studentService: StudentService,
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
  ) { }

  ngOnInit(): void {
    this.getCountry();
    this.getStudentList();

    this.studentForm = this.fb.group({
      email: ['',[Validators.required, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$')]],
      password: ['', [Validators.required]],
      country: ['', Validators.required],
      state: ['', Validators.required]
    });
  }

  get studentControl() {
    return this.studentForm.controls;
  }

  //#region  country and state
  getCountry() {
    this.studentService.getCountry().subscribe({
      next: (value: any) => {
        this.countryList = value;
      },
      error: (error: any) => {
        console.error(error)
      }
    });
  }

  getState(id: any) {

    let countryId = id;
    this.studentForm.controls['state'].setValue('');
    if (countryId == '') {
      this.stateList = null;
      return
    }
    this.studentService.getState(countryId).subscribe({
      next: (value: any) => {
        this.stateList = value;
      },
      error: (error: any) => {
        console.error(error)
      }
    });
  }

  bindState(id: any) {
    this.getState(id);
  }

  //#endregion

  //#region crud operation
  onSave() {
    this.studentService.onSaveStudent(this.studentForm.value).subscribe({
      next: (data: any) => {
        alert("data saved");
        this.onClose();
        this.getStudentList();
      },
      error: (error: any) => {
        console.log(error);
      }
    });
  }

  onUpdate() {
    this.studentService.onUpdateStudent(this.studentForm.value, '1').subscribe({
      next: (data: any) => {
        alert("data updated");
        this.onClose();
        this.getStudentList();
      },
      error: (error: any) => {
        console.log(error);
      }
    });
  }

  getStudentList() {
    this.studentService.getStudentList().subscribe({
      next: (data: any) => {
        this.studentList = data;
      },
      error: (error: any) => {
        console.log(error);
      }
    });
  }

  onStudentEdit(data: any,e:any) {
    debugger
    
    this.getState(data?.country);
    this.studentForm.patchValue({
      email: data?.email,
      password: data?.password,
      country:data?.country,
      state: data?.state
    });
  }

  //#endregion

  onClose() {
    this.submitted = false;
    this.studentForm.reset();
    this.studentControl['country'].setValue('');
    this.studentControl['state'].setValue('');

    let ref = document.getElementById('close');
    ref?.click();

  }


}
